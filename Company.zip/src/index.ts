import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { ErrorResponseInterceptor, HeaderInterceptor } from '@core/interceptor/interceptor';

export const httpInterceptorProviders = [
  { provide: HTTP_INTERCEPTORS, useClass: HeaderInterceptor, multi: true },
  { provide: HTTP_INTERCEPTORS, useClass: ErrorResponseInterceptor, multi: true },
];