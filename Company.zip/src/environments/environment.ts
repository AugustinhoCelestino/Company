export const environment = {
    urlAPI: 'https://localhost:7187/api',
};
