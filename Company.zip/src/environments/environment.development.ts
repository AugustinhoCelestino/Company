export const environment = {
    // urlAPI: 'http://localhost:5000/api',
    urlAPI: 'https://localhost:7126/api',
};
