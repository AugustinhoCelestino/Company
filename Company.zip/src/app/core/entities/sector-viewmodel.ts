export class SectorViewModel {
    id?: number;
    description?:string;
    countryId?: number;
    isActive?: boolean;
}