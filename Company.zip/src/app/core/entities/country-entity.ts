export class CountryEntity {
    id?: string;
    description?:string;
    bacenCountryCode?: string;
    indArt21Circ3644?: string;
}