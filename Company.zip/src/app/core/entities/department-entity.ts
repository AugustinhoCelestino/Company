import { AutoMap } from "@automapper/classes";
import { SectorEntity } from "./sector-entity";

export class DepartmentEntity {

  @AutoMap()
  id: number = 0;
  @AutoMap()
  description: string = '';
  @AutoMap(() => SectorEntity)
  sector: SectorEntity = {};
  @AutoMap()
  isActive: boolean = true;
  @AutoMap()
  origin: string = '';
}

