import { AutoMap } from "@automapper/classes";
import { CountryEntity } from "./country-entity";

export class SectorEntity {
    id?: number = 0;
    description?: string = '';

    @AutoMap(() => CountryEntity)
    country?: CountryEntity  = {};

    isActive?: boolean = true;

    origin?: string = '';
}