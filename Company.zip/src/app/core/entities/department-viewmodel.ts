import { AutoMap } from "@automapper/classes";

export class DepartmentViewModel {

  @AutoMap()
  id: number = 0;

  @AutoMap()
  description: string = '';

  sector: string = '';
  
  country: string = '';

  @AutoMap()
  isActive: boolean = false;
  
  @AutoMap()
  origin: string = '';
}

