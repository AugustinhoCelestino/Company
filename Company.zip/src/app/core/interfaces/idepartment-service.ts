import { Observable } from "rxjs";
import { DepartmentEntity } from "../entities/department-entity";
import { DepartmentViewModel } from "@core/entities/department-viewmodel";

export abstract class IDepartmentService {
    abstract findAll(): Observable<DepartmentViewModel[]>;
    abstract get(id?: number): Observable<DepartmentEntity>;
    abstract create(param: DepartmentEntity): void;
    abstract update(param: DepartmentEntity): void;
    abstract delete(param: DepartmentEntity): void;
}