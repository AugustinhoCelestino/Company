export interface sectorTableData {
    id: string;
    description: string;
    country: {
        description: string;
    };
}

export interface departmentTableData {
    id: string;
    description: string;
    sector: {
        description: string;
    };
}

export interface countryTableData {
    id: string;
    description: string;
}

export interface conglomerateTableData {
    id: string;
    description: string;
}

export interface companyTableData {
    id: string;
    description: string;
    entity: string;
    cnpj: string;
    holding: boolean;
}

export interface holidayTableData {
    id: string;
    company: string;
    entity: string;
    date: string;
}

export interface entityTableData {
    id: string;
    description: string;
    country: string;
}

export interface indexTableData {
    id: string;
    legacy: string;
    family: string;
    to: string;
    from: string;
}

export interface userTableData {
    id: string;
    name: string;
    hierarchy: string;
    email: string;
    phone: string;
    department: string;
    country: string;
}

// more info on screen, screen =/= database
export interface groupTableData {
    id: string;
    name: string;
    description: string;
    domain: string;
}

export interface domainTableData {
    id: string;
    description: string;
    country: string;
}

export interface supplierTableData {
    id: string;
    name: string;
    country: string;
}

export interface systemTypeTableData {
    id: string;
    description: string;
    internal: boolean;
}

// MISS? most important system screen? 
export interface systemTableData {
    id: string;
    name: string;
    description: string;
    systemType: string;
    supplier: string;
    group: string;
    groupIT: string; // IDK
    groupOrg: string; // IDK
    criticalLevel: string;
    RTO: string;
    RPO: string;
    firstDeploy: string;
    securityReview: string;
    qualiSG: boolean;
    restoreFull: boolean;
    packageBNPP: boolean;
    log: boolean;
}

export interface currencyTableData {
    id: string;
    legacy: string; // concat with category + categoryDescription "108 - BANK"
    finance: string; // concat with category + categoryDescription "108 - BANK"
}

export interface importRatingTableData {
    id: string;
    startDate: string;
    endDate: string;
    typeImport: string;
}

export interface holidayB3TableData {
    id: string;
    date: string;
    description: string;
}

// MISS? most important system screen?
export interface clientTableData {
    id: string;
    agency: string;
    account: string;
    name: string;
    classification: string;
    ruleUpdate: string;
    lastUpdate: string;
    clientType: string; // fisica ou juridica?
    cpfCnpj: string;
    category: string;
    industry: string;
    country: string;
}

export interface classificationTableData {
    id: string;
    description: string;
}

export interface paramClassificationTableData {
    id: string;
    classification: string;
    clientType: string;
    cpfCnpj: string;
    industry: string; // concat with category + categoryDescription "108 - BANK"
    category: string; // concat with category + categoryDescription "108 - BANK"
    country: string;
    ruleEconomicGroup: string;
    art21: boolean;
    representBNPP: boolean;
    expirationDateStart: string;
    expirationDateEnd: string;
}

export interface billingOfficerTableData {
    id: string;
    cpfOfficer: string;
    billing: string;
}
