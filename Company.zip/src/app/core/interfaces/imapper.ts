export abstract class IMapper<O, E> {
    abstract mapFrom(param: O): E;
    abstract mapTo(param: E): O;
}