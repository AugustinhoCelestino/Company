import { DepartmentEntity } from "@core/entities/department-entity";
import { DepartmentViewModel } from "@core/entities/department-viewmodel";
import { Observable } from "rxjs";

export abstract class IDepartmentController {
    abstract findAll(): Observable<DepartmentViewModel[]>;
    abstract get(id?: number): Observable<DepartmentEntity>;
    abstract create(param: DepartmentEntity): void;
    abstract update(param: DepartmentEntity): void;
    abstract delete(param: DepartmentEntity): void;
}