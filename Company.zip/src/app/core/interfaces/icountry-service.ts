import { Observable } from "rxjs";
import { CountryEntity } from "../entities/country-entity";

export abstract class ICountryService {
    abstract findAll(): Observable<CountryEntity[]>;
    abstract get(param: CountryEntity): Observable<CountryEntity>;
    abstract create(param: CountryEntity): Observable<CountryEntity>;
    abstract update(param: CountryEntity): Observable<CountryEntity>;
    abstract delete(param: CountryEntity): Observable<CountryEntity>;
}