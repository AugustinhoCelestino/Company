import { Observable } from "rxjs";
import { CountryEntity } from "../entities/country-entity";

export abstract class ICountryController {
    abstract getNew(): CountryEntity;
    abstract findAll(): Observable<CountryEntity[]>;
    abstract get(country: CountryEntity): Observable<CountryEntity>;
    abstract create(country: CountryEntity): Observable<CountryEntity>;
    abstract update(country: CountryEntity): Observable<CountryEntity>;
    abstract delete(country: CountryEntity): Observable<CountryEntity>;
}