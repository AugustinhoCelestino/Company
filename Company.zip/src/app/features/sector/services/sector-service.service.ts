import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { SectorEntity } from '@core/entities/sector-entity';

@Injectable({
  providedIn: 'root'
})
export class SectorServiceService {

  constructor(
    private http: HttpClient
  ) { }

  findAll(): Observable<SectorEntity[]> {
    return this.http.get<SectorEntity[]>(environment.urlAPI + '/sector');
  }

  get(sector: SectorEntity): Observable<SectorEntity> {
    return this.http.get<SectorEntity>(environment.urlAPI + '/sector/' + sector.id);
  }

  create(sector: SectorEntity): Observable<SectorEntity> {
    return this.http.post(environment.urlAPI + '/sector', sector);
  }

  update(sector: SectorEntity): Observable<SectorEntity> {
    return this.http.put(environment.urlAPI + '/sector/' + sector.id, sector);
  }

  delete(sector: SectorEntity): Observable<SectorEntity> {
    return this.http.delete(environment.urlAPI + '/sector/' + sector.id);
  }
}