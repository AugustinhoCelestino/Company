import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ICountryService } from '../../core/interfaces/icountry-service';
import { CountryService } from './services/country-service.service';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers: [
    { provide: ICountryService, useClass: CountryService }
  ]
})
export class CountryModule { }
