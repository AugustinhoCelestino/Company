import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ICountryService } from '../../../core/interfaces/icountry-service';
import { Observable } from 'rxjs';
import { CountryEntity } from '../../../core/entities/country-entity';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CountryService implements ICountryService {

  constructor(
    private http: HttpClient
  ) { }

  findAll(): Observable<CountryEntity[]> {
    return this.http.get<CountryEntity[]>(environment.urlAPI + '/country');
  }

  get(country: CountryEntity): Observable<CountryEntity> {
    return this.http.get<CountryEntity>(environment.urlAPI + '/country/' + country.id);
  }

  create(country: CountryEntity): Observable<CountryEntity> {
    return this.http.post(environment.urlAPI + '/country', country);
  }

  update(country: CountryEntity): Observable<CountryEntity> {
    return this.http.put(environment.urlAPI + '/country/' + country.id, country);
  }

  delete(country: CountryEntity): Observable<CountryEntity> {
    return this.http.delete(environment.urlAPI + '/country/' + country.id);
  }
}
