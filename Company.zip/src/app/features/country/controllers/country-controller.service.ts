import { Injectable } from '@angular/core';
import { ICountryController } from '../../../core/interfaces/icountry-controller';
import { Observable } from 'rxjs';
import { CountryEntity } from '../../../core/entities/country-entity';
import { ICountryService } from '../../../core/interfaces/icountry-service';

@Injectable({
  providedIn: 'root'
})
export class CountryControllerService implements ICountryController {

  constructor(
    private countryService: ICountryService
  ) { }
  
  getNew(): CountryEntity {
    // TODO: inicializar com valores default
    return {
      id: '',
      description: '',
      bacenCountryCode: 'AAA',
      indArt21Circ3644: 'S',
    };
  }

  findAll(): Observable<CountryEntity[]> {
    return this.countryService.findAll();
  }
  get(country: CountryEntity): Observable<CountryEntity> {
    return this.countryService.get(country);
  }
  create(country: CountryEntity): Observable<CountryEntity> {
    return this.countryService.create(country);
  }
  update(country: CountryEntity): Observable<CountryEntity>{
    return this.countryService.update(country);
  }
  delete(country: CountryEntity): Observable<CountryEntity> {
    return this.countryService.delete(country);
  }
}
