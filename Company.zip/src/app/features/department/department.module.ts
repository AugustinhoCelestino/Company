import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IDepartmentService } from '../../core/interfaces/idepartment-service';
import { DepartmentService } from './services/department.service';
import { HttpClientModule } from '@angular/common/http';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HttpClientModule
  ],
  providers: [
    { provide: IDepartmentService, useClass: DepartmentService}
  ]
})
export class DepartmentModule { }
