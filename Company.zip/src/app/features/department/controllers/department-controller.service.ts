import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DepartmentEntity } from '@core/entities/department-entity';
import { IDepartmentService } from '@core/interfaces/idepartment-service';
import { IDepartmentController } from '@core/interfaces/idepartment-controller';
import { DepartmentViewModel } from '@core/entities/department-viewmodel';

@Injectable({
  providedIn: 'root'
})
export class DepartmentControllerService implements IDepartmentController {

  constructor(
    private departmentService: IDepartmentService
  ) { }

  findAll(): Observable<DepartmentViewModel[]> {
    return this.departmentService.findAll();
  }

  get(id?: number): Observable<DepartmentEntity> {
    return this.departmentService.get(id);
  }
  create(param: DepartmentEntity): void {
    return this.departmentService.create(param);
  }
  update(param: DepartmentEntity): void {
    return this.departmentService.update(param);
  }
  delete(param: DepartmentEntity): void {
    return this.departmentService.delete(param);
  }
}
