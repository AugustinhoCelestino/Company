import { TestBed } from '@angular/core/testing';

import { DepartmentControllerService } from './department-controller.service';

describe('DepartmentControllerService', () => {
  let service: DepartmentControllerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DepartmentControllerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
