import { IMapper } from "@core/interfaces/imapper";
import { DepartmentEntity } from "@core/entities/department-entity";
import { createMap, forMember, mapFrom } from '@automapper/core'
import { mapper } from "@shared/helpers/mapper";
import { DepartmentViewModel } from "@core/entities/department-viewmodel";
import { Injectable } from "@angular/core";

createMap(mapper, DepartmentEntity, DepartmentViewModel,
    forMember(
        (destination) => destination.sector,
        mapFrom((source) => source.sector.description)
    ),
    forMember(
        (destination) => destination.country,
        mapFrom((source) => source.sector.country?.description)
    )    
)

@Injectable({
    providedIn: 'root'
})  

  
export class DepartmentMapper implements IMapper<DepartmentEntity, DepartmentViewModel> {

    mapFrom(param: DepartmentEntity): DepartmentViewModel {
        return mapper.map(param, DepartmentEntity, DepartmentViewModel)
    }

    mapTo(param: DepartmentViewModel): DepartmentEntity {
        return mapper.map(param, DepartmentViewModel, DepartmentEntity)
    }
}