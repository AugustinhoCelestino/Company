import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable, map, of } from 'rxjs';
import { DepartmentEntity } from '@core/entities/department-entity';
import { IDepartmentService } from '@core/interfaces/idepartment-service';
import { MockService } from '@shared/helpers/mock.service';
import { DepartmentViewModel } from '@core/entities/department-viewmodel';
import { environment } from 'src/environments/environment';
import { DepartmentMapper } from './department-mapper';


@Injectable({
  providedIn: 'root'
})

export class DepartmentService implements IDepartmentService{

  constructor(
    private http: HttpClient,
    private mock: MockService,
    private mapper: DepartmentMapper
  ) { }

  findAll(): Observable<DepartmentViewModel[]> {

    const mockData = this.mock.generate(DepartmentEntity, 150) as DepartmentEntity[];
    
    return this.http.get<DepartmentEntity[]>(environment.urlAPI + '/department').pipe(
      // map((departments): DepartmentViewModel[] => departments.map(this.mapper.mapFrom))
      map((departments): DepartmentViewModel[] => mockData.map(this.mapper.mapFrom))
    );

    // return of<DepartmentEntity[]>(mockData);
  }

  get(id?: number): Observable<DepartmentEntity> {

    const mockData = this.mock.generate(DepartmentEntity, 1) as DepartmentEntity[];

    return of<DepartmentEntity>(mockData[0])

    // return this.http.get<DepartmentEntity>(environment.urlAPI + '/department/' + id);
  }

  create(param: DepartmentEntity) {
    return of(console.log('//TODO create'))
    // return this.http.post(environment.urlAPI + '/department');
  }

  update(param: DepartmentEntity) {
    return of(console.log('//TODO update'))
    // return this.http.put(environment.urlAPI + '/department/' + param.id);
  }

  delete(param: DepartmentEntity) {
    return of(console.log('//TODO delete'))
    // return this.http.delete(environment.urlAPI + '/department/' + param.id);
  }

}