import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { HomeComponent } from './pages/home/home.component';
import { SectorComponent } from './pages/transversal/sector/sector.component';
import { DepartmentComponent } from './pages/transversal/department/department.component';
import { CountryComponent } from './pages/transversal/country/country.component';
import { ConglomerateComponent } from './pages/transversal/conglomerate/conglomerate.component';
import { HolidayComponent } from './pages/transversal/holiday/holiday.component';
import { EntityComponent } from './pages/transversal/entity/entity.component';
import { IndexComponent } from './pages/transversal/index/index.component';
import { UserComponent } from './pages/transversal/user/user.component';
import { GroupComponent } from './pages/transversal/group/group.component';
import { DomainComponent } from './pages/transversal/domain/domain.component';
import { SupplierComponent } from './pages/transversal/supplier/supplier.component';
import { SystemTypeComponent } from './pages/transversal/system-type/system-type.component';
import { SystemComponent } from './pages/transversal/system/system.component';
import { CurrencyComponent } from './pages/transversal/currency/currency.component';
import { ImportRatingComponent } from './pages/transversal/import-rating/import-rating.component';
import { HolidayB3Component } from './pages/transversal/holiday-b3/holiday-b3.component';
import { ClientComponent } from './pages/finance/client/client.component';
import { ClassificationComponent } from './pages/finance/classification/classification.component';
import { ParamClassificationComponent } from './pages/finance/param-classification/param-classification.component';
import { BillingOfficerComponent } from './pages/finance/billing-officer/billing-officer.component';
import { CompanyComponent } from './pages/transversal/company/company.component';

export const routes: Routes = [
    { path: '', redirectTo: '/login', pathMatch: 'full'},
    { path: 'login', component: LoginComponent },
    { path: 'home', component: HomeComponent },
    { path: 'sector', component: SectorComponent },
    { path: 'department', component: DepartmentComponent },
    { path: 'country', component: CountryComponent },
    { path: 'conglomerate', component: ConglomerateComponent },
    { path: 'company', component: CompanyComponent },
    { path: 'holiday', component: HolidayComponent },
    { path: 'entity', component: EntityComponent },
    { path: 'index', component: IndexComponent },
    { path: 'user', component: UserComponent },
    { path: 'group', component: GroupComponent },
    { path: 'domain', component: DomainComponent },
    { path: 'supplier', component: SupplierComponent },
    { path: 'systemType', component: SystemTypeComponent },
    { path: 'system', component: SystemComponent },
    { path: 'currency', component: CurrencyComponent },
    { path: 'importRating', component: ImportRatingComponent },
    { path: 'holidayB3', component: HolidayB3Component },
    { path: 'client', component: ClientComponent },
    { path: 'classification', component: ClassificationComponent },
    { path: 'paramClassification', component: ParamClassificationComponent },
    { path: 'billingOfficer', component: BillingOfficerComponent },
    { path: '**', redirectTo: '/login', pathMatch: 'full'},

];
