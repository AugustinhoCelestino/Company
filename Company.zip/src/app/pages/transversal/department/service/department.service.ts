import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DepartmentEntity } from '@core/entities/department-entity';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  private url = environment.urlAPI + '/department';

  constructor(
    private http: HttpClient
  ) { }

  get(): Observable<DepartmentEntity[]> {
    return this.http.get<DepartmentEntity[]>(this.url);
  }

  create(department: DepartmentEntity): Observable<DepartmentEntity>{
    return this.http.post<DepartmentEntity>(this.url, department);
  }

  read(department: DepartmentEntity): Observable<DepartmentEntity> {
    return this.http.get<DepartmentEntity>(this.url + "/" + department.id);
  }

  update(department: DepartmentEntity): Observable<DepartmentEntity> {
    return this.http.put<DepartmentEntity>(this.url + "/" + department.id, department);
  }

  delete(department: DepartmentEntity): Observable<DepartmentEntity> {
    return this.http.delete<DepartmentEntity>(this.url + "/" + department.id);
  }

}
