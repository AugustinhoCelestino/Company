import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';
import { DepartmentControllerService } from '@features/department/controllers/department-controller.service';
import { DepartmentModule } from '@features/department/department.module';
import { DepartmentService } from './service/department.service';
import { LoadingScreenComponent } from '@shared/components/loading-screen/loading-screen.component';
import { DepartmentEntity } from '@core/entities/department-entity';
import { IDepartmentController } from '@core/interfaces/idepartment-controller';


@Component({
  selector: 'app-department',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent, DepartmentModule, LoadingScreenComponent],
  providers: [
    { provide: IDepartmentController, useClass: DepartmentControllerService }
  ],
  templateUrl: './department.component.html',
  styleUrl: './department.component.scss'
})
export class DepartmentComponent implements OnInit {

  loading = true;
  departmentData: DepartmentEntity[] = [];
  departmentEmpty: DepartmentEntity = new DepartmentEntity();

  constructor(
    private departmentController: IDepartmentController,
    private service: DepartmentService,
  ) {

  }

  ngOnInit(): void {
    this.getAllDepartments();
  }

  createDepartment(department: DepartmentEntity) {
    this.service.create(department).subscribe({
      next: (data) => {
        this.getAllDepartments();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Department created!')
    });
  }

  readDepartment() {
    this.service.read(this.departmentEmpty).subscribe({
      next: (data) => console.log(data),
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Department BR read!')
    });
  }

  updateDepartment(department: DepartmentEntity) {
    this.service.update(department).subscribe({
      next: (data) => {
        this.getAllDepartments();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Department BR deleted!')
    });
  }

  deleteDepartment(department: DepartmentEntity) {
    this.service.delete(department).subscribe({
      next: (data) => {
        this.getAllDepartments();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Department ' + department.description + ' was deleted!')
    });
  }

  getAllDepartments() {
    this.loading = true;
    this.service.get().subscribe({
      next: (data) => {
        this.departmentData = data;
        this.loading = false;
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Department data loaded!')
    });

  }

}
