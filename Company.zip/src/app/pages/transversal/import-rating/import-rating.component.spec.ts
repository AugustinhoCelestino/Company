import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportRatingComponent } from './import-rating.component';

describe('ImportRatingComponent', () => {
  let component: ImportRatingComponent;
  let fixture: ComponentFixture<ImportRatingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImportRatingComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ImportRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
