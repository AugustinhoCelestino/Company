import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';

@Component({
  selector: 'app-import-rating',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent],
  templateUrl: './import-rating.component.html',
  styleUrl: './import-rating.component.scss'
})
export class ImportRatingComponent {

}
