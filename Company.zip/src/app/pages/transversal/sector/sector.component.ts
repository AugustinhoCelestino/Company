import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';
import { LoadingScreenComponent } from '@shared/components/loading-screen/loading-screen.component';
import { SectorService } from './service/sector.service';
import { SectorEntity } from '@core/entities/sector-entity';

@Component({
  selector: 'app-sector',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent, LoadingScreenComponent],
  templateUrl: './sector.component.html',
  styleUrl: './sector.component.scss'
})
export class SectorComponent {

  loading = true;
  sectorData: SectorEntity[] = [];
  sectorEmpty: SectorEntity = new SectorEntity();

  constructor(
    private service: SectorService,
  ) {

  }

  ngOnInit(): void {
    this.getAllSectors();
  }

  createSector(sector: SectorEntity) {
    this.service.create(sector).subscribe({
      next: (data) => {
        this.getAllSectors();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Sector created!')
    });
  }

  readSector() {
    this.service.read(this.sectorEmpty).subscribe({
      next: (data) => console.log(data),
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Sector BR read!')
    });
  }

  updateSector(sector: SectorEntity) {
    this.service.update(sector).subscribe({
      next: (data) => {
        this.getAllSectors();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Sector BR deleted!')
    });
  }

  deleteSector(sector: SectorEntity) {
    this.service.delete(sector).subscribe({
      next: (data) => {
        this.getAllSectors();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Sector ' + sector.description + ' was deleted!')
    });
  }

  getAllSectors() {
    this.loading = true;
    this.service.get().subscribe({
      next: (data) => {
        this.sectorData = data;
        this.loading = false;
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Sector data loaded!')
    });

  }


}
