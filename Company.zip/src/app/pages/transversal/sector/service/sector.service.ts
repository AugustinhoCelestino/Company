import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SectorEntity } from '@core/entities/sector-entity';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SectorService {

  private url = environment.urlAPI + '/sector';

  constructor(
    private http: HttpClient
  ) { }

  get(): Observable<SectorEntity[]> {
    return this.http.get<SectorEntity[]>(this.url);
  }

  create(sector: SectorEntity): Observable<SectorEntity>{
    return this.http.post<SectorEntity>(this.url, sector);
  }

  read(sector: SectorEntity): Observable<SectorEntity> {
    return this.http.get<SectorEntity>(this.url + "/" + sector.id);
  }

  update(sector: SectorEntity): Observable<SectorEntity> {
    return this.http.put<SectorEntity>(this.url + "/" + sector.id, sector);
  }

  delete(sector: SectorEntity): Observable<SectorEntity> {
    return this.http.delete<SectorEntity>(this.url + "/" + sector.id);
  }

}