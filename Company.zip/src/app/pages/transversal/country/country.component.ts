import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';
import { LoadingScreenComponent } from '@shared/components/loading-screen/loading-screen.component';
import { CountryControllerService } from '@features/country/controllers/country-controller.service';
import { CountryModule } from '@features/country/country.module';
import { ICountryController } from '@core/interfaces/icountry-controller';
import { CountryEntity } from '@core/entities/country-entity';


@Component({
  selector: 'app-country',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent, LoadingScreenComponent, CountryModule],
  providers: [
    { provide: ICountryController, useClass: CountryControllerService }
  ],
  templateUrl: './country.component.html',
  styleUrl: './country.component.scss'
})
export class CountryComponent implements OnInit {

  loading = true;
  countryData: CountryEntity[] = [];

  constructor(
    private countryService: ICountryController
  ) { }

  ngOnInit(): void {
    this.getAllCountries();
  }

  getNewCountry():CountryEntity {
    return this.countryService.getNew();
  }

  createCountry(country: CountryEntity) {
    this.countryService.create(country).subscribe({
      next: (data) => {
        this.getAllCountries();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Country created!')
    });
  }

  readCountry(country: CountryEntity) {
    this.countryService.get(country).subscribe({
      next: (data) => console.log(data),
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Country BR read!')
    });
  }

  updateCountry(country: CountryEntity) {
    this.countryService.update(country).subscribe({
      next: (data) => {
        this.getAllCountries();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Country BR deleted!')
    });
  }

  deleteCountry(country: CountryEntity) {
    this.countryService.delete(country).subscribe({
      next: (data) => {
        this.getAllCountries();
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Country ' + country.description + ' was deleted!')
    });
  }

  getAllCountries() {
    this.loading = true;
    this.countryService.findAll().subscribe({
      next: (data) => {
        this.countryData = data;
        this.loading = false;
      },
      error: (e) => console.error('TO DO: criar um padrão de errors, porque o interc não quer parar o IE error'),
      complete: () => console.info('Country data loaded!')
    });
  }

}
