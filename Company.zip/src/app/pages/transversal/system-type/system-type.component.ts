import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';

@Component({
  selector: 'app-system-type',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent],
  templateUrl: './system-type.component.html',
  styleUrl: './system-type.component.scss'
})
export class SystemTypeComponent {

}
