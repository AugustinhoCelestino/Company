import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';

@Component({
  selector: 'app-holiday-b3',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent],
  templateUrl: './holiday-b3.component.html',
  styleUrl: './holiday-b3.component.scss'
})
export class HolidayB3Component {

}
