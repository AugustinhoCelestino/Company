import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HolidayB3Component } from './holiday-b3.component';

describe('HolidayB3Component', () => {
  let component: HolidayB3Component;
  let fixture: ComponentFixture<HolidayB3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HolidayB3Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HolidayB3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
