import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';

@Component({
  selector: 'app-entity',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent],
  templateUrl: './entity.component.html',
  styleUrl: './entity.component.scss'
})
export class EntityComponent {

}
