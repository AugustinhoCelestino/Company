import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';

@Component({
  selector: 'app-param-classification',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent],
  templateUrl: './param-classification.component.html',
  styleUrl: './param-classification.component.scss'
})
export class ParamClassificationComponent {

}
