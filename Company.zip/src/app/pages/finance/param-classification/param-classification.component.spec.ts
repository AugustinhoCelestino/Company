import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParamClassificationComponent } from './param-classification.component';

describe('ParamClassificationComponent', () => {
  let component: ParamClassificationComponent;
  let fixture: ComponentFixture<ParamClassificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ParamClassificationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ParamClassificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
