import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableBuilderComponent } from '@shared/components/table-builder/table-builder.component';

@Component({
  selector: 'app-billing-officer',
  standalone: true,
  imports: [CommonModule, TableBuilderComponent],
  templateUrl: './billing-officer.component.html',
  styleUrl: './billing-officer.component.scss'
})
export class BillingOfficerComponent {

}
