import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingOfficerComponent } from './billing-officer.component';

describe('BillingOfficerComponent', () => {
  let component: BillingOfficerComponent;
  let fixture: ComponentFixture<BillingOfficerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BillingOfficerComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BillingOfficerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
