import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../../material.module';

@Component({
  selector: 'app-radiogroup',
  standalone: true,
  imports: [CommonModule, MaterialModule],
  templateUrl: './radiogroup.component.html',
  styleUrl: './radiogroup.component.scss'
})
export class RadiogroupComponent {
  favoriteSeason: string = '';
  seasons: string[] = ['Winter', 'Spring', 'Summer', 'Autumn'];
}
