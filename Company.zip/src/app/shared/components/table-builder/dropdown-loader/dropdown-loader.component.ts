import { Injectable } from '@angular/core';
import { CountryService } from '@features/country/services/country-service.service';
import { SectorServiceService } from '@features/sector/services/sector-service.service';

@Injectable({
    providedIn: 'root'
})
export class DropdownLoader {
    constructor(
        private _sectorService: SectorServiceService,
        private _countryService: CountryService
    ) { }

    async getSectorData(): Promise<any> {
        let sectorData: any[] = [];
        let sectors = await this._sectorService.findAll().toPromise();
        if (sectors) {
            sectors.forEach((sector) => {
                sectorData.push({
                    key: sector.id,
                    value: sector.description,
                    dataBinded: sector
                });
            });
            return sectorData;
        }
    }
    
    async getCountryData(): Promise<any> {
        let countryData: any[] = [];
        let countrys = await this._countryService.findAll().toPromise();
        if (countrys) {
            countrys.forEach((country) => {
                countryData.push({
                    key: country.id,
                    value: country.description,
                    dataBinded: country
                });
            });
            return countryData;
        }
    }
}
