import { Component, ElementRef, EventEmitter, Inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { tables, IColumn, generateEmptyData } from './table-builder.config';
import * as XLSX from 'xlsx';
import Swal from 'sweetalert2';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { MaterialModule } from '../../material.module';
import { TableDialog } from './table-dialog/table-dialog.component';

export interface filterData {
  name: string;
  columnProp: string;
  options: any[];
  modelValue: any;
}

@Component({
  selector: 'app-table-builder',
  standalone: true,
  imports: [CommonModule, MaterialModule],
  templateUrl: './table-builder.component.html',
  styleUrl: './table-builder.component.scss'
})
export class TableBuilderComponent implements OnInit {

  // default values to DOM render table with no data
  dataSource: any;
  displayedColumns: string[] = ['id'];
  columnsToShow: IColumn[] = [{
    columnDef: "id",
    header: "Id",
    cell: (element: any) => `${element.id}`,
    showed: false,
    isRequired: false,
    maxSize: 999,
    autoIncrement: true,
    isDropdown: false,
    tableToLoad: 'none',
  }];
  maxColumnShow: number = 5;

  // filtering values
  filterValues: any;
  filterSelectObj: filterData[] = [];
  filterByColumn: boolean = false;
  defaultFilterPredicate?: (data: any, filter: string) => boolean;

  tableName: string = '';
  tableDescription: string = '';
  tableColumns: IColumn[] = [];
  hasExternalData: boolean = false;
  loaded: boolean = false;

  // intel text
  overloadFieldsText = 'Esta tabela possui muitos campos! alguns não estão sendo exibidos, basta clicar em colunas para escolher quais campos serão exibidos.';

  @Input() tableType!: string;
  @Input() tableSource: any;
  @Input() emptyData: any;

  @Output() createFunction = new EventEmitter<any>();
  @Output() reloadFunction = new EventEmitter<any>();
  @Output() updateFunction = new EventEmitter<any>();
  @Output() deleteFunction = new EventEmitter<any>();

  @ViewChild(MatPaginator) paginator!: MatPaginator | null;
  @ViewChild(MatSort) sort!: MatSort | null;

  @ViewChild('TABLE') table!: ElementRef;

  constructor(
    private snackBar: MatSnackBar,
    public dialog: MatDialog
  ) {
    this.dataSource = new MatTableDataSource(generateEmptyData());
  }

  ngOnInit(): void {
    this.setTableValues();
    this.setTableConfig();
    this.setTableDataSource();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.overloadFields() ? this.openSnackBar(this.overloadFieldsText) : console.log('');
  }

  setFilterByColumn() {
    this.defaultFilterPredicate = this.dataSource.filterPredicate;
    this.dataSource.filterPredicate = this.createFilter();
    this.filterByColumn = true;
  }

  setFilterByAll() {
    this.dataSource.filterPredicate = this.defaultFilterPredicate;
    this.filterByColumn = false;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  // Reset table filters
  resetFilters() {
    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    this.dataSource.filter = "";
  }

  // Custom filter method for Angular Material Datatable
  createFilter() {
    let filterFunction = function (data: any, filter: string): boolean {
      let searchTerms = JSON.parse(filter);
      let isFilterSet = false;
      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }

      let nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            searchTerms[col].trim().toLowerCase().split(' ').forEach((word: any) => {
              if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
                found = true
              }
            });
          }
          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }

  // Get Unique (ID'S) values from columns to build filter
  filterChange(filter: filterData, event: any) {
    this.filterValues = {}
    this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase();
    this.dataSource.filter = JSON.stringify(this.filterValues)
  }

  setTableValues() {
    const tableTypeKey = this.tableType as keyof typeof tables;
    this.tableName = tables[tableTypeKey].tableName;
    this.hasExternalData = tables[tableTypeKey].hasExternalData;
    this.tableDescription = tables[tableTypeKey].tableDescription;
    this.tableColumns = tables[tableTypeKey].columns;
    this.tableColumns.filter((x, index) => {
      x.showed = (this.maxColumnShow > index)
    });
  }

  setTableConfig() {
    this.columnsToShow = [];
    this.filterSelectObj = [];
    this.displayedColumns = [];
    this.tableColumns.forEach((columnFounded, index) => {
      if (columnFounded.showed) {
        this.columnsToShow.push(columnFounded);
        this.displayedColumns.push(columnFounded.columnDef);
        this.filterSelectObj.push({
          name: columnFounded.header,
          columnProp: columnFounded.columnDef,
          options: [],
          modelValue: null,
        });
      }
    });
    this.displayedColumns = [...this.displayedColumns, 'action'];


    this.filterSelectObj.filter((o) => {
      o.options = this.getFilterObject(this.tableSource, o.columnProp);
    });
  }

  setTableDataSource() {
    this.dataSource = new MatTableDataSource(this.tableSource);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.loaded = true;
  }

  columnsShow(): IColumn[] {
    return this.columnsToShow.filter((column) => column.showed);
  }

  displayedColumnsShow() {
    return this.columnsToShow.filter((column) => column.showed);
  }

  // Get Uniqu values from columns to build filter
  getFilterObject(fullObj: any[], key: string) {
    const uniqChk: any[] = [];
    fullObj?.filter((obj: { [x: string]: any; }) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }

  exportToExcel() {
    const filename = this.tableName + '.xlsx';
    const ws = XLSX.utils.json_to_sheet(this.tableSource);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, this.tableType);
    XLSX.writeFile(wb, filename);
    Swal.fire({
      title: filename + " gerado com Sucesso!",
      text: "O arquivo está pronto, e será baixado e assim que acabar estará disponivel na sua pasta de download (:",
      icon: "success"
    });
  }

  callbackDelete(dataToDelete: any) {
    Swal.fire({
      title: "Tem certeza?",
      text: "Excluir esse resgistro pode ser inreversivel!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#00915a",
      cancelButtonColor: "#b4babf",
      confirmButtonText: "Sim, excluir",
      cancelButtonText: "Não",
    }).then((result) => {
      if (result.isConfirmed) {
        this.deleteFunction.emit(dataToDelete);
        Swal.fire({
          title: "Excluido!",
          text: "o resgisto foi excluido com sucesso.",
          icon: "success"
        });
      }
    });
  }

  callbackUpdate(dataToUpdate: any): void {
    const dialogRef = this.dialog.open(TableDialog, {
      data: {
        tableName: this.tableName,
        tableColumns: this.tableColumns,
        hasExternalData: this.hasExternalData,
        isEdit: true,
        dataId: dataToUpdate.Id,
        dataToEdit: dataToUpdate,
      }
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.updateFunction.emit(dialogResult.dataToEdit);
      }
      else {
        this.reloadFunction.emit();
      }
    });
  }

  callbackCreate(): void {
    const dialogRef = this.dialog.open(TableDialog, {
      data: {
        tableName: this.tableName,
        tableColumns: this.tableColumns,
        hasExternalData: this.hasExternalData,
        isEdit: false,
        dataId: 0,
        dataToEdit: this.emptyData,
      }
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        this.createFunction.emit(dialogResult.dataToEdit);
      }
      else {
        this.reloadFunction.emit();
      }
    });
  }

  openSnackBar(snackBarText: string) {
    this.snackBar.open(snackBarText, 'close', {
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  }

  overloadFields(): boolean {
    return (this.tableColumns.length > this.maxColumnShow);
  }

}
