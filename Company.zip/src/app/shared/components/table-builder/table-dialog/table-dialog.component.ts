import { Component, Inject, OnInit } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material/dialog";
import { MaterialModule } from "@shared/material.module";
import { IColumn } from "../table-builder.config";
import { DropdownLoader } from "../dropdown-loader/dropdown-loader.component";
import { LoadingScreenComponent } from "@shared/components/loading-screen/loading-screen.component";

export interface TableDialogData {
  tableName: string;
  tableColumns: IColumn[];
  hasExternalData: boolean;
  isEdit: boolean;
  dataId: string;
  dataToEdit: any;
}

@Component({
  selector: 'table-dialog',
  templateUrl: 'table-dialog.html',
  standalone: true,
  imports: [MaterialModule, LoadingScreenComponent],
  styleUrl: './table-dialog.component.scss'
})

export class TableDialog implements OnInit {

  loading: boolean = true;
  dropdownsData: any[] = [];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: TableDialogData,
    public dialogRef: MatDialogRef<TableDialog>,
    private dropdownLoader: DropdownLoader

  ) {
    dialogRef.disableClose = true;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  sendData(): void {
    this.dialogRef.close(this.data);
  }

  ngOnInit() {
    if (this.data.hasExternalData) {
      let dropdownsToLoad = this.data.tableColumns.filter(c => c.isDropdown);
      dropdownsToLoad.forEach(dropdown => {
        this.loadDropdown(dropdown.tableToLoad);
      });
    }
    this.loading = false;
  }

  async loadDropdown(dropdown: string) {
    switch (dropdown) {
      case 'sector': {
        this.dropdownsData.push({
          dropdownKey: 'sector',
          dropdownValue: await this.dropdownLoader.getSectorData(),
        })
        break;
      }
      case 'country': {
        this.dropdownsData.push({
          dropdownKey: 'country',
          dropdownValue: await this.dropdownLoader.getCountryData(),
        })
        break;
      }
      case 'none': {
        //statements; 
        break;
      }
      default: {
        //statements; 
        break;
      }
    }
  }

  getDropdownsByKey(columnData: string): any[] {
    let dropdownsData = this.dropdownsData.find(c => c.dropdownKey == columnData);
    if (dropdownsData) {
      return dropdownsData.dropdownValue;
    }
    else {
      return [];
    }
  }

  setDataFromId(columnData: string, event: any){
    let dropdown  = this.dropdownsData.find(c => c.dropdownKey == columnData);
    let dropdownSelectedItem = dropdown.dropdownValue.find((x: { key: any; }) => x.key == event.target.value);
    this.data.dataToEdit[columnData] = dropdownSelectedItem.dataBinded;
  }
}