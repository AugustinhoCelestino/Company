import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../../material.module';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, MaterialModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.scss'
})
export class NavbarComponent {
  constructor(
    private route: ActivatedRoute,
    private router: Router
  ) { }

  public goTo(url: string) {
    this.router.navigateByUrl(url);
  }

  public isNotLogin(): boolean {
    return !(this.router.url === '/login');
  }
}
