import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../../material.module';

@Component({
  selector: 'app-button',
  standalone: true,
  imports: [CommonModule, MaterialModule],
  templateUrl: './button.component.html',
  styleUrl: './button.component.scss'
})
export class ButtonComponent {

  @Input() public label: string = '';
  @Input() public disabled: boolean = false;
  @Input() public type = '' || 'primary' || 'accent' || 'warn'


}
