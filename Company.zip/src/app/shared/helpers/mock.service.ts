import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})

export class MockService {

    _stringListA = [
        'excellent', 'literate', 'simple', 'actually', 'suitable', 'known', 'coordinated', 'chunky', 'sparkling', 'itchy', 'purring', 'supreme', 'popular', 'far-flung', 'helpless', 'straight', 'unable', 'annoying', 'bouncy', 'teeny', 'different', 'earsplitting', 'habitual', 'incandescent', 'nostalgic', 'black', 'gamy', 'conscious', 'rotten', 'nonchalant', 'uncovered', 'realistic', 'entire', 'ethereal', 'unequaled', 'volatile', 'jumpy', 'fair', 'smelly', 'lamentable', 'hungry', 'fluttering', 'naughty', 'juicy', 'immediate', 'deeply', 'voracious', 'beneficial', 'red', 'hissing'
    ]

    _stringListB = [
        'citizen', 'handy', 'issue', 'gown', 'pit', 'lack', 'voyage', 'curve', 'quarrel', 'path', 'native', 'rub', 'conscious', 'bus', 'creed', 'command', 'sigh', 'standard', 'forum', 'spell', 'Venus', 'bind', 'captain', 'strict', 'fantasy', 'vision', 'cane', 'series', 'stuff', 'lobby', 'text', 'owe', 'prove', 'transmission', 'penalty', 'stay', 'coal', 'soldier', 'stride', 'size', 'credibility', 'exempt', 'favourite', 'chart', 'blame', 'pull', 'suit', 'profound', 'slide', 'arrangement'
    ]

    public generate<typeToMock>(typeParam: any, Mocksize: number = 10,): typeToMock[] {

        const _objBase: typeToMock = this.creatorType(typeParam);

        const _properties = Object.getOwnPropertyNames(_objBase);

        let mockArray: typeToMock[] = [];

        for (let i = 1; i <= Mocksize; i++) {
            let mockObj: any = {};
            _properties.forEach(prop => {
                const typeKey = prop as keyof typeof _objBase;
                if (typeof (_objBase[typeKey]) == 'number') {
                    mockObj[prop] = i;
                }
                else if (typeof (_objBase[typeKey]) == 'string') {
                    mockObj[prop] = this.stringGen();
                }
                else if (typeof (_objBase[typeKey]) == 'boolean') {
                    mockObj[prop] = this.booleanGen();
                }
                else {
                    mockObj[prop] = null;
                }
            });
            mockArray.push(mockObj);
        }

        return mockArray;
    }

    private creatorType<typeToCreate>(type: { new(): typeToCreate; }): typeToCreate {
        return new type();
    }

    private stringGen(): string {
        return this._stringListA[Math.floor(Math.random() * this._stringListA.length)] + ' ' + this._stringListB[Math.floor(Math.random() * this._stringListB.length)];
    }

    private booleanGen(): boolean {
        return (Math.floor(Math.random()*100) % 2 === 0);
    }
}
